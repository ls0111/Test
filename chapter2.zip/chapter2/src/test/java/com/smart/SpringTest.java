package com.smart;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
* @author 作者 louys:
* @version 创建时间：2017年9月12日 上午9:46:07
* 类说明
*/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="/smart-context.xml")
public class SpringTest {

}
