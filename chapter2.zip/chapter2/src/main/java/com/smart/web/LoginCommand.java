package com.smart.web;
/**
* @author 作者 louys:
* @version 创建时间：2017年9月13日 上午9:05:31
* 类说明
*/
public class LoginCommand {
	String userName;
	String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
